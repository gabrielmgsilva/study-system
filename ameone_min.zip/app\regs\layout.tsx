// src/app/app/regs/layout.tsx
import React from 'react';

import AppShell from '@/components/AppShell';
import ModuleGate from '@/lib/ModuleGate';
import { ROUTES } from '@/lib/routes';

export default function Layout({ children }: { children: React.ReactNode }) {
  return (
    <AppShell
      title="REGS (Global)"
      subtitle="CARs + Standards shared across licences"
      backHref={ROUTES.hub}
      backLabel="Back to Hub"
      maxWidthClass="max-w-6xl"
    >
      <ModuleGate licenseId="regs" title="REGS (Global)" backHref={ROUTES.hub}>
        {children}
      </ModuleGate>
    </AppShell>
  );
}
