'use client';

import React from 'react';
import EntitlementGuard from '@/components/EntitlementGuard';

import AdvancedEngine, { DeckSection, RawQuestion } from '@/components/study/AdvancedEngine';

import carsData from '../../../../data/regs/CARs.json';
import standardsData from '../../../../data/regs/Standards.json';

export default function RegsPage() {
  const title = 'REGS (Global) — CARs & Standards';

  const sections: DeckSection[] = [
    {
      id: 'cars',
      title: 'CARs',
      shortTitle: 'CARs',
      subtitle: 'Canadian Aviation Regulations (exam-focused).',
      weight: 1,
      questions: carsData as RawQuestion[],
    },
    {
      id: 'standards',
      title: 'Standards',
      shortTitle: 'STD',
      subtitle: 'Associated standards used in REGS/BREGS exams.',
      weight: 1,
      questions: standardsData as RawQuestion[],
    },
  ];

  return (
    <EntitlementGuard moduleKey="regs.core" title={title}>
      <AdvancedEngine
        licenseId="regs"
        moduleId="regs"
        moduleTitle={title}
        moduleDescription="Unlock once → shared REGS content (CARs + Standards) across all licences."
        sections={sections}
        enableCredits={true}
        examCost={1}
        defaultTestQuestionCount={50}
      />
    </EntitlementGuard>
  );
}
